"""Unit tests for the shop application."""
# from django.test import TestCase

# Create your tests here.
