/*global DateTimeShortcuts, SelectFilter*/
/**
 * Django admin inlines
 * Based on jQuery Formset 1.1
 * @author Stanislaus Madueke
 * @requires jQuery 1.2.6 or later
 * Modified for Django by Jannis Leidel, Travis Swicegood, and Julien Phalip.
 * Licensed under the New BSD License
 * See: https://opensource.org/licenses/bsd-license.php
 */
'use strict';
{
    const $ = django.jQuery;
    $.fn.formset = function(opts) {
        const options = $.extend({}, $.fn.formset.defaults, opts);
        const $this = $(this);
        const $parent = $this.parent();
        const updateElementIndex = function(el, prefix, ndx) {
            const id_regex = new RegExp("(" + prefix + "-(\\d+|__prefix__))");
            const replacement = prefix + "-" + ndx;
            ["for", "id", "name"].forEach(attr => {
                if ($(el).prop(attr)) {
                    $(el).prop(attr, $(el).prop(attr).replace(id_regex, replacement));
                }
            });
        };
        const totalForms = $("#id_" + options.prefix + "-TOTAL_FORMS").prop("autocomplete", "off");
        const maxForms = $("#id_" + options.prefix + "-MAX_NUM_FORMS").prop("autocomplete", "off");
        const minForms = $("#id_" + options.prefix + "-MIN_NUM_FORMS").prop("autocomplete", "off");
        let nextIndex = parseInt(totalForms.val(), 10);
        let addButton;

        const toggleDeleteButtonVisibility = function(inlineGroup) {
            inlineGroup.find('.inline-deletelink').toggle((minForms.val() === '' || totalForms.val() > minForms.val()));
        };

        const addInlineDeleteButton = function(row) {
            const container = row.is("tr") ? ":last" : row.is("ul, ol") ? "" : ":first";
            const wrapper = row.is("ul, ol") ? "<li>" : "<div>";
            row.children(container).append(`${wrapper}<a class="${options.deleteCssClass}" href="#">${options.deleteText}</a></div>`);
            row.find("a." + options.deleteCssClass).on('click', inlineDeleteHandler.bind(this));
        };

        const inlineDeleteHandler = function(e) {
            e.preventDefault();
            const row = $(e.target).closest('.' + options.formCssClass);
            row.prev(".row-form-errors").remove();
            row.remove();
            nextIndex -= 1;
            const forms = $("." + options.formCssClass);
            totalForms.val(forms.length);
            if (maxForms.val() === '' || forms.length < maxForms.val()) {
                addButton.parent().show();
            }
            toggleDeleteButtonVisibility(row.closest('.inline-group'));
            forms.each((i, form) => {
                updateElementIndex($(form), options.prefix, i);
                $(form).find("*").each((_, el) => updateElementIndex(el, options.prefix, i));
            });
        };

        const addInlineClickHandler = function(e) {
            e.preventDefault();
            const template = $("#" + options.prefix + "-empty");
            const row = template.clone(true).removeClass(options.emptyCssClass).addClass(options.formCssClass).attr("id", options.prefix + "-" + nextIndex);
            addInlineDeleteButton(row);
            row.find("*").each((_, el) => updateElementIndex(el, options.prefix, totalForms.val()));
            row.insertBefore(template);
            totalForms.val(parseInt(totalForms.val(), 10) + 1);
            nextIndex += 1;
            if (maxForms.val() !== '' && totalForms.val() >= maxForms.val()) {
                addButton.parent().hide();
            }
            toggleDeleteButtonVisibility(row.closest('.inline-group'));
            options.added?.(row);
            row.get(0).dispatchEvent(new CustomEvent("formset:added", {
                bubbles: true,
                detail: { formsetName: options.prefix }
            }));
        };

        const addInlineAddButton = function() {
            if (!addButton) {
                const container = $this.prop("tagName") === "TR" ? "tr" : "div";
                const numCols = $this.eq(-1).children().length;
                const addMarkup = container === "tr"
                    ? `<tr class="${options.addCssClass}"><td colspan="${numCols}"><a href="#">${options.addText}</a></td></tr>`
                    : `<div class="${options.addCssClass}"><a href="#">${options.addText}</a></div>`;
                $this.filter(":last").after(addMarkup);
                addButton = $parent.find(container + ":last a");
            }
            addButton.on('click', addInlineClickHandler);
        };

        $this.each((_, el) => $(el).not("." + options.emptyCssClass).addClass(options.formCssClass));
        $this.filter('.' + options.formCssClass + ':not(.has_original):not(.' + options.emptyCssClass + ')').each((_, row) => addInlineDeleteButton($(row)));
        toggleDeleteButtonVisibility($this);
        addInlineAddButton();
        addButton.parent().toggle(maxForms.val() === '' || maxForms.val() > totalForms.val());
        return this;
    };

    $.fn.formset.defaults = {
        prefix: "form",
        addText: "add another",
        deleteText: "remove",
        addCssClass: "add-row",
        deleteCssClass: "delete-row",
        emptyCssClass: "empty-row",
        formCssClass: "dynamic-form",
        added: null,
        removed: null,
        addButton: null
    };

    const reinitHelpers = function() {
        if (typeof DateTimeShortcuts !== "undefined") {
            $(".datetimeshortcuts").remove();
            DateTimeShortcuts.init();
        }
        if (typeof SelectFilter !== "undefined") {
            $(".selectfilter").each((_, el) => SelectFilter.init(el.id, el.dataset.fieldName, false));
            $(".selectfilterstacked").each((_, el) => SelectFilter.init(el.id, el.dataset.fieldName, true));
        }
    };

    $.fn.tabularFormset = function(selector, options) {
        return this.formset({
            ...options,
            formCssClass: "dynamic-" + options.prefix,
            deleteCssClass: "inline-deletelink",
            emptyCssClass: "empty-form",
            added: function(row) {
                reinitHelpers();
                row.find('.prepopulated_field').each((_, field) => {
                    const input = $(field).find('input, select, textarea');
                    const dependencies = (input.data('dependency_list') || []).map(dep => '#' + row.find('.field-' + dep).find('input, select, textarea').attr('id'));
                    if (dependencies.length) input.prepopulate(dependencies, input.attr('maxlength'));
                });
            }
        });
    };

    $.fn.stackedFormset = function(selector, options) {
        const updateInlineLabel = function(row) {
            $(selector).find(".inline_label").each((i, label) => $(label).html($(label).html().replace(/(#\d+)/g, "#" + (i + 1))));
        };
        return this.formset({
            ...options,
            formCssClass: "dynamic-" + options.prefix,
            deleteCssClass: "inline-deletelink",
            emptyCssClass: "empty-form",
            added: function(row) {
                reinitHelpers();
                updateInlineLabel(row);
                row.find('.prepopulated_field').each((_, field) => {
                    const input = $(field).find('input, select, textarea');
                    const dependencies = (input.data('dependency_list') || []).map(dep => {
                        const fieldElement = row.find('.field-' + dep);
                        return '#' + (fieldElement.length ? fieldElement : row.find('.form-row.field-' + dep)).find('input, select, textarea').attr('id');
                    });
                    if (dependencies.length) input.prepopulate(dependencies, input.attr('maxlength'));
                });
            },
            removed: updateInlineLabel
        });
    };

    $(document).ready(function() {
        $(".js-inline-admin-formset").each(function() {
            const data = $(this).data(), inlineOptions = data.inlineFormset;
            const selector = `${inlineOptions.name}-group .${data.inlineType === "tabular" ? "tabular.inline-related tbody:first > tr.form-row" : "inline-related"}`;
            $(selector)[data.inlineType === "tabular" ? 'tabularFormset' : 'stackedFormset'](selector, inlineOptions.options);
        });
    });
}
